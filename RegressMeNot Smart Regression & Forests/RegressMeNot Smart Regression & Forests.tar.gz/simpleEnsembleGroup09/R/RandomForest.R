
#' Check Input Consistency for Predictive Modeling
#'
#' Ensures that the predictor matrix X and the response vector y are compatible for modeling:
#' specifically, it checks that X and y have the same number of rows and handles any missing values.
#'
#' @param y A vector representing the response variable.
#' @param X A matrix or data frame of predictor variables.
#'
#' @return A list containing the cleaned response vector and predictor matrix.
#' @details Missing values in either y or X lead to the removal of corresponding rows in both.
#'
#' @examples
#' y <- c(1, 2, NA, 4)
#' X <- matrix(c(1, 2, 3, 4, NA, 6, 7, 8), ncol = 2)
#' clean_data <- check_input(y, X)
#'
#' @export

check_input <- function(y, X) {

  # Check if number of rows in X is equal to length of y
  if (nrow(X) != length(y)) {
    stop("Invalid input: Number of rows in X must be equal to length of y.")
  }

  # Check for missing values in y and X
  na_y <- sum(is.na(y))
  na_X <- sum(is.na(X))
  if (na_y > 0) {
    warning(paste("Missing values detected in y:", na_y, "rows removed."))
    na_idx <- which(is.na(y))
    y <- y[-na_idx]
    X <- X[-na_idx,]
  }

  if (na_X > 0) {
    # Remove rows with any NA values
    na_rows <- which(rowSums(is.na(X)) > 0)
    if (length(na_rows) > 0) {
      warning(paste("Rows with NA values detected:", length(na_rows), "rows removed."))
      X <- X[-na_rows,]
      y <- y[-na_rows]
    }
  }

  return(list(y = y, X = X))
}

#' Random Search for Random Forest Hyperparameters
#'
#' Performs a random search over specified hyperparameters for the random forest model to find the
#' combination that maximizes accuracy.
#'
#' @param y The response variable vector.
#' @param X The predictor variables matrix.
#' @param n_iter The number of iterations for the random search.
#' @param test_size The proportion of the dataset to hold out for testing.
#'
#' @return A list with the best parameters found and the corresponding accuracy.
#' @details The function randomly selects values for the number of trees (ntree), the number of variables
#' considered at each split (mtry), and the minimum size of terminal nodes (nodesize), assessing each combination
#' by its predictive accuracy on the test set.
#'
#' @examples
#' y <- sample(1:3, 100, replace = TRUE)
#' X <- matrix(rnorm(300), ncol = 3)
#' results <- random_forest_random_search(y, X, n_iter = 5, test_size = 0.2)
#'
#' @export

random_forest_random_search <- function(x, Y, n_iter = 10, test_size = 0.2) {
  best_accuracy <- 0
  best_params <- NULL

  set.seed(123)  # Set seed for reproducibility outside the loop

  for (i in 1:n_iter) {
    ntree <- sample(100:500, 1)
    mtry <- sample(1:ncol(X), 1)
    nodesize <- sample(1:10, 1)

    split_idx <- sample(1:nrow(X), size = floor((1 - test_size) * nrow(X)))
    X_train <- X[split_idx, ]
    y_train <- y[split_idx]
    X_test <- X[-split_idx, ]
    y_test <- y[-split_idx]

    rf <- randomForest(as.factor(y_train) ~ ., data = as.data.frame(X_train), ntree = ntree, mtry = mtry, nodesize = nodesize)
    accuracy <- sum(predict(rf, newdata = as.data.frame(X_test)) == y_test) / length(y_test)
    print(accuracy)
    if (accuracy > best_accuracy) {
      best_accuracy <- accuracy
      best_params <- list(ntree = ntree, mtry = mtry, nodesize = nodesize)
    }
  }

  return(list(best_params = best_params, best_accuracy = best_accuracy))
}

#' Fit a Random Forest Model
#'
#' Fits a random forest model to the data using either user-specified or automatically tuned hyperparameters.
#' It checks input data consistency, optionally performs hyperparameter tuning, and then fits the model.
#'
#' @param y The response vector, either numeric or factor.
#' @param X The predictor matrix.
#' @param ntree Optional; the number of trees in the forest. If NULL, hyperparameters are tuned automatically.
#' @param mtry Optional; the number of variables considered at each split. If NULL, hyperparameters are tuned automatically.
#' @param nodesize Optional; the minimum size of terminal nodes. If NULL, hyperparameters are tuned automatically.
#'
#' @return A list containing the fitted model object, accuracy of the model (if applicable), and other performance metrics (if applicable).
#' @details This function can handle both classification and regression tasks based on the nature of the response variable y.
#' It first ensures data consistency and absence of missing values through `check_input`, then uses either the provided or
#' tuned hyperparameters to fit the model.
#'
#' @examples
#' data <- read.csv("https://raw.githubusercontent.com/adityarana14/MainData/main/Price.csv", header = TRUE)
#' y <- data$price  # Select the response variable column
#' X <- data[, !names(data) %in% c("price")]
#' result <- random_forest(y, X)
#' model <- result$model
#' accuracy <- result$accuracy
#' other_metrics <- result$other_metrics
#' @export

random_forest <- function(y, X, ntree = NULL, mtry = NULL, nodesize = NULL) {

  if (!requireNamespace("randomForest", quietly = TRUE)) {
    # If not, install randomForest
    install.packages("randomForest")
    message("The 'randomForest' package was not installed. It has been installed now.")
  }
  library(randomForest)

  input <- check_input(y, X)
  y <- input$y
  X <- input$X

  if (is.null(ntree) || is.null(mtry) || is.null(nodesize)) {
    # If hyperparameters are not provided, use random search to find them
    tuning_result <- random_forest_random_search(y, X)
    ntree <- tuning_result$best_params$ntree
    mtry <- tuning_result$best_params$mtry
    nodesize <- tuning_result$best_params$nodesize
  }


  if (length(unique(y)) == 2) {
    rf <- randomForest(as.factor(y) ~ ., data = as.data.frame(X), ntree = ntree, mtry = mtry, nodesize = nodesize)
    accuracy <- sum(predict(rf, newdata = as.data.frame(X)) == y) / length(y)
    other_metrics <- NULL
  } else if (length(unique(y)) <= 5) {
    y_binary <- ifelse(y == mean(y), 0, 1)
    rf <- randomForest(as.factor(y_binary) ~ ., data = as.data.frame(X), ntree = ntree, mtry = mtry, nodesize = nodesize)
    accuracy <- sum(predict(rf, newdata = as.data.frame(X)) == y_binary) / length(y_binary)
    other_metrics <- NULL
    warning("The response variable has been converted to binary due to few unique values.")
  } else {
    rf <- randomForest(y ~ ., data = as.data.frame(X), ntree = ntree, mtry = mtry, nodesize = nodesize)
    accuracy <- NULL
    mae <- mean(abs(predict(rf) - y))
    mse <- mean((predict(rf) - y)^2)
    rmse <- sqrt(mean((predict(rf) - y)^2))
    r_squared <- 1 - sum((y - predict(rf))^2) / sum((y - mean(y))^2)
    other_metrics <- list(MAE = mae, MSE = mse, RMSE = rmse, R_squared = r_squared)
  }

  return(list(model = rf, accuracy = accuracy, other_metrics = other_metrics))
}

