
#' Automated Elastic Net Regression Function
#'
#' This function fits an Elastic Net model to a given dataset using glmnet. It manages missing data,
#' automatically detects the response variable type, and allows for optional bagging to stabilize
#' model predictions. It also determines optimal values for the Elastic Net mixing parameter alpha
#' and the regularization parameter lambda through cross-validation if they are not provided.
#'
#' @description The `autoElasticRegression` function first converts the predictor data frame into a
#' model matrix, then handles missing values and converts binary response variables to numeric if needed.
#' The function auto-detects the data type of the response variable (binary or continuous) and fits an
#' Elastic Net model accordingly. If alpha and lambda are not provided, it uses cross-validation to
#' find optimal values. When bagging is enabled, it fits multiple models on bootstrapped samples of
#' the data and averages the predictions.
#'
#' @param X A matrix or data frame of predictor variables with observations in rows and predictors in columns.
#' @param y A vector representing the response variable, which can be either a factor (binary) or numeric (continuous).
#' @param lambda Optional; a numeric value specifying the regularization parameter in the Elastic Net model.
#' If NULL, lambda is determined through cross-validation.
#' @param alpha Optional; a numeric value specifying the Elastic Net mixing parameter between ridge (0) and lasso (1).
#' If NULL, alpha is determined through cross-validation.
#' @param family Optional; a character string specifying the type of model to fit, either 'binary' for binary outcomes or 'continuous' for continuous outcomes. If NULL, the type is automatically detected.
#' @param bagging A boolean indicating whether bagging should be employed. If TRUE, multiple samples of
#' the data are used to fit separate Elastic Net models, and the results are averaged.
#' @param n_bags An integer specifying the number of bootstrap samples to use if bagging is enabled.
#'
#' @return Returns a list with several components:
#' \describe{
#'   \item{model}{The Elastic Net model object from the last bag or single model fit, depending on whether
#'   bagging was used.}
#'   \item{type}{A character string indicating the detected or specified type of the model ('binary' or 'continuous').}
#'   \item{predictions}{A vector of predictions from the final model. If bagging is used, these are the averaged predictions across all bags.}
#'   \item{importance_scores}{A numeric vector indicating the importance of each predictor, available only when bagging is used.}
#' }
#'
#' @examples
#' # Example: Generating data and applying autoElasticRegression
#' set.seed(123)
#' X <- matrix(rnorm(100 * 4), ncol = 4)
#' y <- sample(0:1, 100, replace = TRUE)
#'
#' # Running the function without bagging
#' result <- autoElasticRegression(X, y)
#'
#' # Running the function with bagging to improve estimates
#' result_bagged <- autoElasticRegression(X, y, bagging = TRUE, n_bags = 50)
#'
#' @export
#'
autoElasticRegression <- function(X, y, lambda = NULL, alpha = NULL, family = NULL, bagging = FALSE, n_bags = 50) {

  if (!requireNamespace("glmnet", quietly = TRUE)) {
    # If not, install glmnet
    install.packages("glmnet")
    message("The 'glmnet' package was not installed. It has been installed now.")
  }
  library(glmnet)

  if (is.data.frame(X)) {
    X <- as.matrix(X)
  }
  # X <- model.matrix(~ . - 1, data = X)
  # Handle missing data in X and y
  missing_data <- sum(is.na(X)) + sum(is.na(y))
  if (missing_data > 0) {
    cat("Missing values detected:", missing_data, "\n")
    na_indices <- which(is.na(y) | rowSums(is.na(X)) > 0)
    X <- X[-na_indices, , drop = FALSE]
    y <- y[-na_indices]
    cat("Missing values removed:", length(na_indices), "\n")
  }

  unique_y <- unique(y)
  if (length(unique_y) == 2) {
    if (!is.numeric(y)) {
      # Explicitly map the two unique levels to 0 and 1
      levels <- sort(unique_y)  # Sort to ensure consistent mapping
      y <- factor(y, levels = levels)
      y <- as.integer(y) - 1  # Convert factor to integer and adjust to 0 and 1
      cat(sprintf("Response variable y converted to numeric: %s as 0, %s as 1.\n", levels[1], levels[2]))
    }
  }

  # Auto-detect data type based on unique values
  detected_type <- ifelse(length(unique(y)) == 2 && all(unique(as.numeric(y)) %in% c(0, 1)), "binary", "continuous")

  # Map 'binary' to 'binomial' and 'continuous' to 'gaussian' for glmnet usage
  glmnet_family <- ifelse(detected_type == "binary", "binomial", "gaussian")

  # Verify provided family against detected type
  if (!is.null(family)) {
    if (!tolower(family) %in% c("binary", "continuous")) {
      stop("Invalid family specified. Use 'binary' or 'continuous'.")
    }
    if (family != detected_type) {
      stop("Provided family does not match the detected data type.")
    }
    cat("Provided family and detected type match: ", family, "\n")
  } else {
    family <- detected_type
    cat("Family auto-detected as: ", family, "\n")
  }

  # Initialize importance scores
  importance_scores <- rep(0, ncol(X))

  # Initialize predictions
  predictions <- matrix(0, nrow = nrow(X), ncol = n_bags)

  # Determine alpha and lambda if not provided
  if (is.null(alpha) || is.null(lambda)){
    alph_lamb <- data.frame(matrix(ncol = 3, nrow = 0))
    alphavec = seq(0, 1, 0.1)

    for (i in 1:length(alphavec)) {
      fit <- cv.glmnet(X, y, alpha = alphavec[i], nfolds = 10, family = glmnet_family)
      min_mse <- min(fit$cvm)
      lam <- fit$lambda[which(fit$cvm == min_mse)]
      alph_lamb <- rbind(alph_lamb, c(alphavec[i], lam, min_mse))
    }

    colnames(alph_lamb) <- c("alpha", "lambda", "cvm")

    min_cvm <- min(alph_lamb$cvm)
    opt_alpha <- alph_lamb[which(alph_lamb$cvm == min_cvm), 1]
    opt_lambda <- alph_lamb[which(alph_lamb$cvm == min_cvm), 2]

    if (is.null(alpha)) {
      warning("No 'alpha' provided. Using cross-validation to determine optimal alpha.")
      cat("Optimal alpha used:", opt_alpha, "\n")
      alpha = opt_alpha
    }

    if (is.null(lambda)) {
      warning("No 'lambda' provided. Using cross-validation to determine optimal lambda.")
      cat("Optimal lambda used:", opt_lambda, "\n")
      lambda = opt_lambda
    }
  }

  if (bagging) {
    for (i in 1:n_bags) {
      # Sample with replacement
      indices <- sample(1:nrow(X), replace = TRUE)
      X_bag <- X[indices, , drop = FALSE]
      y_bag <- y[indices]

      model <- glmnet(X_bag, y_bag, family = glmnet_family, lambda = lambda, alpha = alpha)

      # Update importance scores
      coef_matrix <- coef(model, s = lambda)
      importance_scores <- importance_scores + (coef_matrix[-1] != 0)  # Exclude intercept

      # Predict using the original X
      predictions[, i] <- predict(model, newx = X, type = "response", s = lambda)
    }
    # Average the predictions across all bags
    final_predictions <- rowMeans(predictions)
    cat("Bagging complete. Averaged predictions from", n_bags, "models.\n")
    # Report importance scores for each variable
    names(importance_scores) <- colnames(X)
    return(list(model = model, type = family, predictions = final_predictions, importance_scores = importance_scores))
  } else {

    model <- glmnet(X, y, family = glmnet_family, lambda = lambda, alpha = alpha)
    final_predictions <- predict(model, newx = X, type = "response", s = lambda)
    return(list(model = model, type = family, predictions = final_predictions))
  }
}


