#' Automated Logistic Regression Function
#'
#' This function automates the process of fitting a logistic regression model to a provided dataset.
#' It handles missing values, ensures the response variable is binary, and maps non-numeric binary
#' response variables to 0 and 1. Optionally, the function supports bagging to enhance the reliability
#' of model estimates, especially beneficial in noisy datasets.
#'
#' @description The `autoLogisticRegression` function prepares the data by removing missing values and
#' verifying the response variable is binary and numeric (or converting it if necessary). It addresses
#' potential issues of having more predictors than observations by allowing the user to select the top
#' predictors. The logistic regression model is then fitted, with an option to use bagging for improved
#' accuracy and reliability of estimates.
#'
#' @param X A matrix or data frame of predictor variables with observations in rows and predictors in columns.
#' @param y A numeric vector or factor of the binary response variable where each element corresponds to an
#' observation in `X`. Non-numeric binary response variables are automatically converted to numeric.
#' @param bagging A boolean indicating whether bagging should be employed. If TRUE, bagging involves
#' multiple resamplings of the dataset to generate a distribution of estimated coefficients.
#' @param B An integer specifying the number of bootstrap samples to use if bagging is enabled.
#'
#' @return Returns a list containing several components depending on whether bagging was used:
#' \describe{
#'   \item{glm}{A GLM model object representing the fitted logistic regression model.}
#'   \item{coefficients}{A matrix or dataframe of the model coefficients including estimates, standard errors,
#'   z-values, and p-values if bagging is used. Otherwise, it includes estimates and the corresponding p-values.}
#'   \item{fitted.values}{A vector of predicted probabilities using the fitted model.}
#' }
#'
#' @examples
#' # Example: Generating binary response data and applying the autoLogisticRegression function
#' set.seed(123)
#' X <- matrix(rnorm(100 * 4), ncol = 4)
#' y <- sample(0:1, 100, replace = TRUE)
#'
#' # Running the function without bagging
#' result <- autoLogisticRegression(X, y)
#'
#' # Running the function with bagging to improve estimates
#' result_bagged <- autoLogisticRegression(X, y, bagging = TRUE, B = 50)
#'
#' @export

autoLogisticRegression <- function(X, y, bagging = FALSE, B = 100) {
  # Handling NA values
  missing_data <- sum(is.na(X)) + sum(is.na(y))
  if (missing_data > 0) {
    cat("Missing values detected:", missing_data, "\n")
    na_indices <- which(is.na(y) | rowSums(is.na(X)) > 0)
    X <- X[-na_indices, , drop = FALSE]
    y <- y[-na_indices]
    cat("Missing values removed:", length(na_indices), "\n")
  }

  unique_y <- unique(y)
  if (length(unique_y) != 2) {
    stop("Not good data: y should have exactly two unique values.")
  }

  if (!is.numeric(y)) {
    # Explicitly map the two unique levels to 0 and 1
    levels <- sort(unique_y)  # Sort to ensure consistent mapping
    y <- factor(y, levels = levels)
    y <- as.integer(y) - 1  # Convert factor to integer and adjust to 0 and 1
    cat(sprintf("Response variable y converted to numeric: %s as 0, %s as 1.\n", levels[1], levels[2]))
  }

  df <- data.frame(y, X)

  # Check predictor count versus observation count
  n <- dim(X)[1]  # number of observations
  p <- dim(X)[2]  # number of parameters

  if (n < p) {
    warning("The number of predictors is greater than the number of observations. Some variables are eliminated.")
    cat("Reducing the number of predictors due to more predictors than observations.\n")
    k <- min(p - 1, as.integer(readline(prompt = "Enter the number of top predictors to select: ")))
    while (is.na(k) || k >= p) {
      cat("The number of top predictors must be less than the number of predictors.\n")
      k <- as.integer(readline(prompt = "Enter the number of top predictors to select: "))
    }
    res <- autoPreScreenPredictors(X, y, k)
    res <- res$predictor
    df <- df[, c("y", res), drop = FALSE]
  }
  # Fitting the logistic regression model
  fit <- glm(y ~ ., data = df, family = binomial)

  if (bagging) {
    coefficient_names <- names(fit$coefficients)
    est.b <- matrix(NA, nrow = length(fit$coefficients), ncol = B)
    for (i in 1:B) {
      idx <- sample(1:n, n, replace = TRUE)
      df.b <- df[idx, ]
      model <- glm(y ~ ., data = df.b, family = binomial)
      est.b[, i] <- coef(model)[coefficient_names]
    }

    sd.err <- apply(est.b, 1, sd)

    z <- fit$coefficients / sd.err
    pvals <- 2 * pnorm(abs(z), lower.tail = FALSE)

    coefficients <- cbind(Estimate = fit$coefficients, `Std. Error` = sd.err, `z value` = z, `p-value` = pvals)
    fitted.values <- predict(fit, type = "response")

    r <- list(glm = fit, coefficients = coefficients, fitted.values = fitted.values)
  } else {
    coefficients <- cbind(Estimate = coef(summary(fit)), pvals = coef(summary(fit))[,"Pr(>|z|)"])
    fitted.values <- predict(fit, type = "response")

    r <- list(glm = fit, coefficients = coefficients, fitted.values = fitted.values)
  }

  return(r)
}

